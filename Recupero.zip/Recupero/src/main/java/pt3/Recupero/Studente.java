package pt3.Recupero;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class Studente extends Persona{

	private String matricola;
	private boolean lavora;
	
	public Studente(String nome, String cognome,String matricola) {
		super(nome, cognome);
		this.matricola = matricola;
	}
	
	public Studente(String nome, String cognome, String matricola, boolean lavora) {
		super(nome, cognome);
		this.matricola = matricola;
		this.lavora = lavora;
	}

	public boolean isLavora() {
		return lavora;
	}

	public void setLavora(boolean lavora) {
		this.lavora = lavora;
	}

	public String getMatricola() {
		return matricola;
	}
	public void setMatricola(String matricola) {
		this.matricola = matricola;
	}
	public <T> List<? super T> copy(List <? extends T> a,Predicate<T> p){
		List <T>c =new ArrayList<>();
		for(T b : a) {
		if(p.test(b))c.add(b);
		}
		return c;
	}
		
		
		
	}
	
	

	
	
	

