package pt3.Recupero;

public class Docente extends Persona{

	private String dipartimento;
	private boolean ricerca;

	public Docente(String nome, String cognome, String dipartimento) {
		super(nome, cognome);
		this.dipartimento = dipartimento;
	}
	

	public Docente(String nome, String cognome, String dipartimento, boolean ricerca) {
		super(nome, cognome);
		this.dipartimento = dipartimento;
		this.ricerca = ricerca;
	}


	public boolean isRicerca() {
		return ricerca;
	}


	public void setRicerca(boolean ricerca) {
		this.ricerca = ricerca;
	}


	public String getDipartimento() {
		return dipartimento;
	}

	public void setDipartimento(String dipartimento) {
		this.dipartimento = dipartimento;
	}
	
	
}
