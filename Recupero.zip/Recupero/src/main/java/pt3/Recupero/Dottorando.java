package pt3.Recupero;

public class Dottorando extends Studente{

	public Dottorando(String nome, String cognome, String matricola, boolean lavora) {
		super(nome, cognome, matricola, lavora);
		// TODO Auto-generated constructor stub
	}

	public Dottorando(String nome, String cognome, String matricola) {
		super(nome, cognome, matricola);
		// TODO Auto-generated constructor stub
	}
	

}
