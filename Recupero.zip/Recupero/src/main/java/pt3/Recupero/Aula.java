package pt3.Recupero;
import java.util.*;
import java.util.Map.Entry;
public class Aula {
	private String materia;
	private List <Studente> s;
	private List <Docente> d;
	private List <Dottorando> dt;
	private Map <Studente,Integer> vot;
	public Aula(String m, Docente... doc) {
		this.s = new ArrayList<>();
		this.d =  new ArrayList<>(Arrays.asList(doc));
		this.dt = new ArrayList<>();
		this.vot= new HashMap<>();
		this.materia=m;
	}
	
	public String getMateria() {
		return materia;
	}

	public Map<Studente, Integer> getVot() {
		return vot;
	}

	public List<Studente> getS() {
		return s;
	}
	public List<Docente> getD() {
		return d;
	}
	public List<Dottorando> getDt() {
		return dt;
	}
	public void AddStudente() {
		
	}
public void AddDocente(Docente... doc) {
		d.addAll(Arrays.asList(doc));
	}
public void AddStudenti(Studente... doc) {
	s.addAll(Arrays.asList(doc));
}
public void AddDoct(Dottorando... doc) {
	dt.addAll(Arrays.asList(doc));
}
public void AddVotazioni(Entry<String,Integer>... voti) {
	for(Entry<String,Integer> voto:voti) {
		for(Studente stu : s)
			if(stu.getMatricola().equals(voto.getKey()))
				vot.put(stu, voto.getValue());
			
	}
}

	
	
}
