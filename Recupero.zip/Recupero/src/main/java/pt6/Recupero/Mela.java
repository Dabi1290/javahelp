package pt6.Recupero;

public class Mela extends Frutta {

	public Mela(Double peso) {
		super(peso);
		// TODO Auto-generated constructor stub
	}
		
	

}
