package pt6.Recupero;

public class Arancia extends Frutta {

	public Arancia(Double peso) {
		super(peso);
		// TODO Auto-generated constructor stub
	}

}
