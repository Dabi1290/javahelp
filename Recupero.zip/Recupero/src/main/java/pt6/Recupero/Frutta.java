package pt6.Recupero;

public abstract class Frutta {
	private Double Peso;
	

	public Frutta(Double peso) {
		super();
		Peso = peso;
	}

	public Double getPeso() {
		return Peso;
	}

	public void setPeso(Double peso) {
		Peso = peso;
	}

	@Override
	public String toString() {
		return "Frutta [Peso=" + Peso + "]";
	}
	
}
