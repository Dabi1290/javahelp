package pt6.Recupero;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Cesto <T extends Frutta>{
	List <T> frutti;
	public Double getPeso(List <? extends Frutta> f) {
		return f.stream().map(s->s.getPeso()).reduce(0.0, (a,b)->a+b);
	}
	
	public Cesto(List<T> frutti) {
		super();
		this.frutti = frutti;
	}
	public Cesto() {
		super();
		frutti = new ArrayList<T>();
	}

	public void aggiungi(T frutto) throws PesoException{
			if(frutto.getPeso()+this.getPeso(frutti)>5000)throw new PesoException();
				this.frutti.add(frutto);
	}
	public void aggiungi(List<T> frutto) throws PesoException{
		Double sum=frutto.stream().mapToDouble(f->f.getPeso()).sum();
		if(sum+this.getPeso(frutti)>5000)throw new PesoException();
		for(T a :frutto)
			this.frutti.add(a);
	}
	public List<T> max2(){
		List<T> v=this.frutti.stream().sorted(Comparator.comparingDouble(Frutta::getPeso)).collect(Collectors.toList());
		Collections.reverse(v);
		return v.stream().limit(2).collect(Collectors.toList());
	}

	@Override
	public String toString() {
		return "Cesto [frutti=" + frutti + "]";
	}
	
	
	
}
