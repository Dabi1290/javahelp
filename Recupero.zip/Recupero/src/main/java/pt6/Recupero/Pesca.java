package pt6.Recupero;

public class Pesca extends Frutta {

	public Pesca(Double peso) {
		super(peso);
		// TODO Auto-generated constructor stub
	}

}
