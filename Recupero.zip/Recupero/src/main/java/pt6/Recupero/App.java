package pt6.Recupero;

public class App 
{
    public static void main( String[] args )
    {
        Cesto<Arancia> CestoArancie = new Cesto<>();
        
        
        try {
			CestoArancie.aggiungi(new Arancia(2.0));
			CestoArancie.aggiungi(new Arancia(0.4));
			CestoArancie.aggiungi(new Arancia(0.3));
			CestoArancie.aggiungi(new Arancia(1.5));
		} catch (PesoException e) {
			e.printStackTrace();
		};
		
		System.out.println(CestoArancie);
		System.out.println(CestoArancie.max2());
    }
}