package pt6.Recupero;

public class PesoException extends Exception {
	private static final long serialVersionUID = 1L;

	public PesoException() {
		super("Hai superato il peso");
	}
}
