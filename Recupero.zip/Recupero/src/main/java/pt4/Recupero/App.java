package pt4.Recupero;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.HashSet;
import java.util.Set;

public class App {
	
	
	
	public static Integer calc(Set<rotta> l,String b) {
		l.stream().filter(a->a.getOrigine().equals(b)).forEach(System.out::println);
		Long p=l.stream().filter(a->a.getOrigine().equals(b)).count();
		return p.intValue();
		/*for(rotta a:l) {
			if(a.getOrigine().equals(b))
		}*/
		
	}
	
		
	
	
	
	
	public static void main(String[] args) throws IOException {
		 BufferedReader in= new BufferedReader(new InputStreamReader(System.in));
		 FileReader f= new FileReader("target/testrotte.txt");
		 StreamTokenizer st= new StreamTokenizer(f);
		 
		 System.out.println("Inserisci origine destinazione id x y usando la virgola come separatore");
		 String origine,destinazione;
		 int id;
		 Set<rotta> rotte= new HashSet<rotta>();
		 Double x,y;
		 int i=0;
		 while(i<5) {
			 st.nextToken();
			origine=st.sval;
			 st.nextToken();
			destinazione=st.sval;
			 st.nextToken();
			id=(int)st.nval;
			 st.nextToken();
			x=st.nval;
			 st.nextToken();
			y=st.nval;
			 
		
		rotta r=new rotta(origine,destinazione,id,x,y);
		rotte.add(r);
		i++;
		 }
		 st= new StreamTokenizer(in);
		 System.out.println("Inserisci origine da confrontare");
		 st.nextToken();
		 origine=st.sval;
		App.calc(rotte, origine);
		
			
			
		
		 
			
	}

}	
