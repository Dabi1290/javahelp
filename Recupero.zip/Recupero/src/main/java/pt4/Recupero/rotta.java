package pt4.Recupero;



/*
 Realizzare un programma Java che crei una sequenza senza
duplicati di oggetti che modellano una rotta aerea contenente origine,
destinazione, identificativo univoco e posizione cartesiana corrente (x, y e
z). Tali oggetti devono essere creati chiedendo i valori all’utente ed
acquisendoli da tastiera usando la classe StreamTokenizer. Dopo
l’inserimento nella sequenza, il programma deve calcolare il numero totale
di voli con la stessa origine, data come parametro di input, e stampare su
file tutte le informazioni di questi voli.
Si realizzi una opportuna eccezione per la gestione di situazioni di errore nel
corso dell’esecuzione del programma.
 */
public class rotta {
	String origine;
	String destinazione;
	int id;
	Double x;
	Double y;
	public Double getX() {
		return x;
	}
	public void setX(Double x) {
		this.x = x;
	}
	public Double getY() {
		return y;
	}
	public void setY(Double y) {
		this.y = y;
	}
	public String getOrigine() {
		return origine;
	}
	public String getDestinazione() {
		return destinazione;
	}
	public int getId() {
		return id;
	}
	public rotta(String origine, String destinazione, int id, Double x, Double y) {
		super();
		this.origine = origine;
		this.destinazione = destinazione;
		this.id = id;
		this.x = x;
		this.y = y;
	}
	@Override
	public String toString() {
		return "rotta " + origine + " destinazione " + destinazione + " id " + id + " x "  + x +  " y " + y;
	}
	
	
}
