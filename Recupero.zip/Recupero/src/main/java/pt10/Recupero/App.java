package pt10.Recupero;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class App {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		Scanner st=new Scanner(new File("target/testing"));
		String nome,cognome,materia;
		Aula classe;
		List <Aula> scuola=new ArrayList<>();
		List <Docente> dlist=new ArrayList<>();
		List <Studente> slist=new ArrayList<>();
		System.out.println("nome cognome materia x2");
		for(int i=0;i<2;i++) {
			nome=st.next();
			cognome=st.next();
			materia=st.next();
			dlist.add(new Docente(nome,cognome,materia));
		}
		System.out.println("nome cognome matricola x4");
		for(int i=0;i<4;i++) {
			nome=st.next();
			cognome=st.next();
			materia=st.next();
			slist.add(new Studente(nome,cognome,materia));
		}
		int uff;
		System.out.println("Inserimento voti");
		for(Studente s:slist) {
			uff=(int) (Math.random()*(3-1+1)+0); 
			System.out.println(uff);
					for(int i=0;i<uff;i++) {
						nome=sc.next();
						s.Addvoto(Studente.Voto.valueOf("_"+nome));
					}
		}
		classe = new Aula(slist,dlist);
		scuola.add(classe);
		System.out.println("Fine Inserimento voti");
		System.out.println("Studenti con almeno 3 voti: "+ classe.numStudenti());
		
		System.out.println("inserisci nome ");
		cognome=sc.next();
		System.out.println("il prof si trova in tot aule: " + App.fds(scuola, cognome));
		System.out.println("i tizi con la media superiore a 6 sono " + App.media(scuola));
		System.out.println("le classi con la media superiore a 6 sono  " + App.magg(scuola));
		sc.close();
		Comparator<Studente> byName = 
				(Studente o1, Studente o2)->o1.getNome().compareTo(o2.getNome());
		Comparator<Studente> bySname = 
						(Studente o1, Studente o2)->o1.getCognome().compareTo(o2.getCognome());
	}
	
	public static Integer fds(List <Aula> scuola,String nome) {
		return (int) scuola.stream().map(f->f.getDocenti()).flatMap(g->g.stream()).filter(h->h.getNome().equals(nome)).count();

}
	public static Integer media(List <Aula> scuola) {
		return (int)scuola.stream().flatMap(f->f.getStudenti().stream().map(g->g.getVoto().stream().mapToDouble(h->h.Converti()).average()))
								.filter(p->p.orElse(0)>6).count();
	}
	public static Integer magg(List <Aula> scuola) {
		
				int mux=0;
				
				//scuola.stream().flatMap(f->f.getStudenti().stream()).mapToDouble(g->g.getVoto().stream().mapToDouble(h->h.Converti()).average().orElse(0)).filter(p->p>7).count();
				for(Aula a : scuola) {
					int studenti= (int) a.getStudenti().stream().count();
					int max=(int)a.getStudenti().stream().mapToDouble(g->g.getVoto().stream().mapToDouble(h->h.Converti()).average().orElse(0)).filter(p->p>7).count();
					if(max>=studenti/2)mux++;
				}
				return mux;
				
				}
	
				
				
	}
	
