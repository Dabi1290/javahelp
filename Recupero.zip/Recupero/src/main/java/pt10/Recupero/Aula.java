package pt10.Recupero;

import java.util.List;

public class Aula {
  private List <Studente> studenti;
  private List <Docente> docenti;
  public Aula(List <Studente> s, List <Docente> d  ) {
	this.setStudenti(s);
	this.setDocenti(d);
}
  public  int numStudenti() {
	  return (int) this.studenti.stream().map(f->f.getVoto()).filter(f->f.stream().count()>=3).count();
  }
public List <Studente> getStudenti() {
	return studenti;
}
public void setStudenti(List <Studente> studenti) {
	this.studenti = studenti;
}
public List <Docente> getDocenti() {
	return docenti;
}
public void setDocenti(List <Docente> docenti) {
	this.docenti = docenti;
}
  
}
