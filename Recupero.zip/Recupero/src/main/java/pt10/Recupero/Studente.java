package pt10.Recupero;


import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Studente {
	private String nome;
	private String cognome;
	private String matricola;
	enum Voto{
		_1,
		_2,
		_3,
		_4,
		_5,
		_6,
		_7,
		_8,
		_9,
		_10;
		public  int Converti() {
			StringTokenizer st = new StringTokenizer(this.toString(),"_");
			return Integer.parseInt(st.nextToken());
			
			
			
			
		}
	}
	private List <Voto> voti;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getMatricola() {
		return matricola;
	}
	public void setMatricola(String matricola) {
		this.matricola = matricola;
	}
	public List<Voto> getVoto() {
		return voti;
	}
	public boolean Addvoto(Voto v) {
		return voti.add(v);
	}
	
	public boolean Rmvoto(int i) {
		return voti.remove(i) != null;
	}
	public Studente(String nome, String cognome, String matricola) {
		super();
		this.nome = nome;
		this.cognome = cognome;
		this.matricola = matricola;
		voti= new ArrayList<>();
	}
	/*public  int Converti(Voto v) {
		StringTokenizer st = new StringTokenizer(v.toString(),"_");
		return Integer.parseInt(st.nextToken());
		
		
		
		
	}*/
	
	
}
