package pt1.Recupero;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;

/**
 * Hello world!
 *
 */


public class App 
{
	
	
	
    public static void main( String[] args )
    {
    	Integer[] a={1,2,3,4,5};
    	for(Integer f :a )System.out.print(f.toString()+" ");
    	Algoritmo.swap(a, 0, 3);
    	System.out.println("");
    	for(Integer f :a )System.out.print(f.toString()+" ");
       Collection <Integer>c=Arrays.asList(1,2,3,4,21);
       int count=Algoritmo.countIf(c, new Oddpredicate());
       System.out.println("\nNumeri dispari= "+count);
       count=Algoritmo.countIf(c, new Evenpredicate());
       System.out.println("Numeri pari= "+count);
       count=Algoritmo.countIf(c, new Palindrompredicate());
       System.out.println("Numeri Palindromi= "+count);
      System.out.println(Algoritmo.max(Arrays.asList(a), 3, 4)); 
    }
}
