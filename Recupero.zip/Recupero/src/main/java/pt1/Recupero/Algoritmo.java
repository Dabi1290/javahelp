package pt1.Recupero;

import java.util.Collection;
import java.util.List;

public class Algoritmo <T>{
	public interface UPredicate<T>{public boolean test(T obj);}
	public static <T> int countIf(Collection <T> c, UPredicate <T> p){
		int count=0;
		for(T elem : c) {
			if(p.test(elem))count++;
			
		}
		return count;
	}
	public static <T> void swap(T[] a,int i,int j) {
		T temp=a[i];
		a[i]=a[j];
		a[j]=temp;
	}
	public static <T extends Comparable<? super T>> T max(List<? extends T> a,int i,int j) {
		T max=a.get(i);
		for(i++;i<j;i++)if(max.compareTo(a.get(i))<0)max=a.get(i);
		return max;
	}
	
}
