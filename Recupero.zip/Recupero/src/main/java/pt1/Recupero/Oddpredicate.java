package pt1.Recupero;

import pt1.Recupero.Algoritmo.UPredicate;

public class Oddpredicate implements UPredicate<Integer>{

	@Override
	public boolean test(Integer obj) {
		return obj%2!=0;
		
	}

}
