package pt1.Recupero;


import java.util.ArrayList;
import java.util.List;

import pt1.Recupero.Algoritmo.UPredicate;

public class Palindrompredicate implements UPredicate<Integer>{

	@Override
	public boolean test(Integer obj) {
		String a=obj.toString();
		int i =0;
		List <String>l=new ArrayList<String>();
		if(a.length()==1)return true;
		while(i<a.length()) {
			l.add(Character.toString(a.charAt(i)));
			i++;
		}
		i=0;
		int f=l.size()-1;
		for(;i<l.size()/2;i++,f--) {
			if(!(l.get(i).equals(l.get(f)))){
				i=-1;break;
			}
		}
		if(i!=-1)return true;
		return false;
	}

}
