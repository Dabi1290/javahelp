package pt8.Recupero;

import java.util.StringTokenizer;

public class Veicolo {
	
	private String Targa;
	private Proprietario p;
	enum Tipo{
		Auto,
		Moto,
		Camion;
	}
	private Tipo t;
	private String OraA;
	private String OraP;
	public String getOraA() {
		return OraA;
	}
	public void setOraA(String oraA) {
		OraA = oraA;
	}
	public String getOraP() {
		return OraP;
	}
	public void setOraP(String oraP) {
		OraP = oraP;
	}
	public String getTarga() {
		return Targa;
	}
	public void setTarga(String targa) {
		Targa = targa;
	}
	public Proprietario getP() {
		return p;
	}
	public void setP(Proprietario p) {
		this.p = p;
	}
	public Tipo getT() {
		return t;
	}
	public void setT(Tipo t) {
		this.t = t;
	}
	public Veicolo(String targa, Proprietario p, Tipo t,String arrivo,String partenza) {
		super();
		Targa = targa;
		this.p = p;
		this.t = t;
		this.OraA=arrivo;
		this.OraP=partenza;
	}
	public Double getTariffaOra() {
		if(this.t.equals(Tipo.Auto))return 2.0;
		if(this.t.equals(Tipo.Camion))return 3.0;
		if(this.t.equals(Tipo.Moto))return 1.0;
		else return 0.0;
	}
	public Double getTariffaFraz() {
		if(this.t.equals(Tipo.Auto))return 1.5;
		if(this.t.equals(Tipo.Camion))return 2.5;
		if(this.t.equals(Tipo.Moto))return 0.5;
		else return 0.0;
	}
	public Double getTotale() {
		Double max;
		StringTokenizer st=new StringTokenizer(this.getOraA());
		;
		max=Double.valueOf(st.nextToken())
	}
	
}
