package pt8.Recupero;

public class Proprietario {
	private String CF;
	private String telefono;
	public String getCF() {
		return CF;
	}
	public void setCF(String cF) {
		CF = cF;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public Proprietario(String cF, String telefono) {
		super();
		CF = cF;
		this.telefono = telefono;
	}
	
	
}
