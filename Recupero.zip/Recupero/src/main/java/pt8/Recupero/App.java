package pt8.Recupero;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class App {
	public static void printpropers(List <Proprietario> p) {
		int i=0;
		for(Proprietario u : p) {
			System.out.println((i+1)+")  "+u.getCF());
			i++;}
	}
	public static void menu() {
		System.out.println("1)Aggiungi veicolo");
		System.out.println("2)Calcola spesa proprietario");
		System.out.println("3)Calcolo guadagno garage");
	}
	
	public static void main(String[] args) throws IOException {
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		StreamTokenizer st= new StreamTokenizer(in);
		List <Veicolo> veicoli=new ArrayList<>();
		List <Proprietario> propers=new ArrayList<>();
		Veicolo v;
		String cf,num,arrivo,partenza;
		Veicolo.Tipo t;
		Proprietario p;
		for(int i=0;i<3;i++) {
			try {
				st.nextToken();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			cf=st.sval;
			try {
				st.nextToken();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			num= String.valueOf(st.nval);
			p=new Proprietario(cf,num);
			propers.add(p);
		}
		int scelta;
		do {
			App.menu();
			try {
				st.nextToken();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			scelta=(int)st.nval;
			switch(scelta) {
			case 1:
				App.printpropers(propers);
				System.out.println("Inserisci Targa Numero_Proprietario Tipo arrivo partenza");
				try {
					st.nextToken();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				cf=st.sval;
				st.nextToken();
				scelta=(int)st.nval;
				st.nextToken();
				t=Veicolo.Tipo.valueOf(st.sval);
				Scanner sc=new Scanner(System.in);
				arrivo=sc.next();
				partenza=sc.next();
				v=new Veicolo(cf,propers.get(scelta-1),t,arrivo,partenza);
				break;
			case 2:
				System.out.println("Di chi vuoi calcolare la spesa?");
				App.printpropers(propers);
				st.nextToken();
				//scelta=(int)st.nval;
				//final int a=scelta;
				double sum=veicoli.stream().filter(f->f.getP().getCF().equals(propers.get((int)st.nval-1).getCF())).mapToDouble(f->f.getTariffaOra()*5).sum();
				System.out.println("Ha speso "+sum);
				break;
			case 3:
				sum=veicoli.stream().mapToDouble(f->f.getTariffaOra()*5).sum();
				System.out.println("Ha gudagnato "+sum);
				break;
			default:break;
			}
			
		}while(true);
		
		

	}

}
