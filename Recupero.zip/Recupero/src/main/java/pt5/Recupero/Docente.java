package pt5.Recupero;

public class Docente extends Persona {
	private String materia;
	public Docente(String nome, String cognome, String codiceFiscale,String materia) {
		super(nome, cognome, codiceFiscale);
		this.materia=materia;
		// TODO Auto-generated constructor stub
	}
	public String getMateria() {
		return materia;
	}
	public void setMateria(String materia) {
		this.materia = materia;
	}
	

}
