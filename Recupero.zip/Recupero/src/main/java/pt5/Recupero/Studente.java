package pt5.Recupero;


import java.util.Collection;
import java.util.HashMap;


public class Studente extends Persona {

	private Integer classe;
	HashMap<String,Double> voti;
	
	
	
	
	public HashMap<String, Double> getVoti() {
		return voti;
	}
	public void setVoti(HashMap<String, Double> voti) {
		this.voti = voti;
	}
	public Studente(String nome, String cognome, String codiceFiscale, Integer classe) {
		super(nome, cognome, codiceFiscale);
		this.classe=classe;
		voti=new HashMap<>();
	}
	public Integer getClasse() {
		return classe;
	}
	public void setClasse(Integer classe) {
		this.classe = classe;
	}
	public boolean addVoto(String materia,Double voto) {
		
			try {
				voti.put(materia, voto);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
			return true;
	}
	public boolean removeVoto(String materia) {
		try {
			this.voti.remove(materia);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}
	public boolean modifyVoto(String materia,Double voto) {
		try {
			this.voti.replace(materia, voto);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}
	public Double media() {
		return voti.values().stream().mapToDouble(null).average().getAsDouble();
		
		
	}
	
	
	

}
