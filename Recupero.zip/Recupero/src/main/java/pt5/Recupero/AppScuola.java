package pt5.Recupero;

public class AppScuola {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
