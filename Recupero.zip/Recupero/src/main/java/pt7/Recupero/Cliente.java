package pt7.Recupero;

public class Cliente {
	private String CF;
	private String Nome;
	private String Cognome;
	private String Comune;
	private String Telefono;
	public Cliente(String cF, String nome, String cognome, String comune, String telefono) {
		super();
		CF = cF;
		Nome = nome;
		Cognome = cognome;
		Comune = comune;
		Telefono = telefono;
	}
	
}
