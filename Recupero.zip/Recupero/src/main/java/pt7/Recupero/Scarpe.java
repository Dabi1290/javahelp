package pt7.Recupero;

public class Scarpe extends Articolo {
	enum Taglia{
		_36,
		_37,
		_38,
		_39,
		_40,
		_41,
		_42,
		_43,
		_44,
		_45,
		_46,
		_47,
		_48;
	}
	private Taglia t;
	public Scarpe(String id, String modello, String casaProd, Integer quantita,Taglia t) {
		super(id, modello, casaProd, quantita, Costo.Scarpe);
		this.t=t;
		// TODO Auto-generated constructor stub
	}

}
