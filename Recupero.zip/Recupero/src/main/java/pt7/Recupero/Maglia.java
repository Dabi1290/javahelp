package pt7.Recupero;

public class Maglia extends Articolo {

	enum Taglia{
		S,
		M,
		L,
		XL;
	}
	private Taglia t;
	public Maglia(String id, String modello, String casaProd, Integer quantita,Taglia o) {
		super(id, modello, casaProd, quantita,Costo.Maglia);
		this.t=o;
		
		// TODO Auto-generated constructor stub
	}

}
