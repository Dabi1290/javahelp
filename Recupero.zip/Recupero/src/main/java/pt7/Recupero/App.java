package pt7.Recupero;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.ArrayList;
import java.util.List;

import pt7.Recupero.Maglia.Taglia;

public class App {
	public static void  menu() {
		System.out.println("1 Crea Ordine");
		System.out.println("2 Paga Ordine");
		System.out.println("3 Esci");
	}
	public static void main(String[] args) {
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		StreamTokenizer st= new StreamTokenizer(in);
		// TODO Auto-generated method stub
		List <Maglia> maglie=new ArrayList<>();
		List <Pantalone> pantaloni= new ArrayList<>();
		List <Scarpe> scarpe = new ArrayList<>();
		List <Cliente> clienti = new ArrayList<>();
		Cliente c;
		Scarpe s;
		Maglia m;
		Pantalone p1;
		String id,modello,casa,comune,telefono;
		Integer quantita;
		Maglia.Taglia t;
		Pantalone.Taglia p;
		Scarpe.Taglia s1;
		System.out.println("MAGLIE   inserisci id modello casaProd quantita Taglia ");
		for(int i=0;i<2;i++) {
			id=st.sval;
			modello=st.sval;
			casa=st.sval;
			quantita=(int)st.nval;
			t=Maglia.Taglia.valueOf(st.sval);
			m=new Maglia(id,modello,casa,quantita,t);
			maglie.add(m);
		}
		System.out.println("PANTALONI   inserisci id modello casaProd quantita Taglia ");
		for(int i=0;i<2;i++) {
			id=st.sval;
			modello=st.sval;
			casa=st.sval;
			quantita=(int)st.nval;
			p=Pantalone.Taglia.valueOf(st.sval);
			p1=new Pantalone(id,modello,casa,quantita,p);
			pantaloni.add(p1);
		}
		System.out.println("SCARPE   id modello casaProd quantita Taglia ");
		for(int i=0;i<2;i++) {
			id=st.sval;
			modello=st.sval;
			casa=st.sval;
			quantita=(int)st.nval;
			s1=Scarpe.Taglia.valueOf(st.sval);
			s=new Scarpe(id,modello,casa,quantita,s1);
			scarpe.add(s);
		}
		System.out.println("CLIENTI   CF nome cognome comune telefono ");
		for(int i=0;i<2;i++) {
			id=st.sval;
			modello=st.sval;
			casa=st.sval;
			comune=st.sval;
			telefono=st.sval;
			c=new Cliente(id,modello,casa,comune,telefono);
			clienti.add(c);
		}
		int  exit;
		do {
			App.menu();
			exit=(int)st.nval;
			switch(exit) {
			case 1:
			case 2:
			default: break;
			}
			
		}while(exit!=3);

	}

}
