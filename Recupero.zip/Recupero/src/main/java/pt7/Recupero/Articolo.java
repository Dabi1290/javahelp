package pt7.Recupero;

public class Articolo {
	private String Id;
	private String Modello;
	private String CasaProd;
	enum Costo{
		Maglia(25),
		Pantalone(30),
		Scarpe(50);
		
	private final Integer costo;
	private Costo(final Integer costo) {this.costo=costo;}
	public Integer getCosto() {
		return this.costo;
	}
		
	}
	
	private Costo costo;
	private Integer Quantita;
	
	public Integer getCosto() {
		return costo.getCosto();
	}
	public void setCosto(Costo costo) {
		this.costo = costo;
	}
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getModello() {
		return Modello;
	}
	public void setModello(String modello) {
		Modello = modello;
	}
	public String getCasaProd() {
		return CasaProd;
	}
	public void setCasaProd(String casaProd) {
		CasaProd = casaProd;
	}
	public Integer getQuantita() {
		return Quantita;
	}
	public void setQuantita(Integer quantita) {
		Quantita = quantita;
	}
	public Articolo(String id, String modello, String casaProd, Integer quantita, Costo c) {
		super();
		Id = id;
		Modello = modello;
		CasaProd = casaProd;
		Quantita = quantita;
		this.costo=c;
	}
	
}
