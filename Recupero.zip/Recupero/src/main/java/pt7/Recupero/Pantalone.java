package pt7.Recupero;

public class Pantalone extends Articolo {

	enum Taglia{
		_44,
		_46,
		_48,
		_50,
		_52;
	}
	private Taglia t;
	public Pantalone(String id, String modello, String casaProd, Integer quantita,Taglia t) {
		super(id, modello, casaProd, quantita,Costo.Pantalone);
		// TODO Auto-generated constructor stub
		this.t=t;
	}

}
