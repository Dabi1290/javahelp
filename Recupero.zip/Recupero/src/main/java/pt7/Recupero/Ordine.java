package pt7.Recupero;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.List;

public class Ordine {
	BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
	StreamTokenizer st= new StreamTokenizer(in);
	private Cliente c;
	
	List <? super Articolo> a;
	enum Stato{
		PAGATO,
		NON_PAGATO;
	}
	private Stato t;
	
	public Ordine(Cliente c, Articolo ... a)throws Exception {
		super();
		this.c = c;
		boolean flag=true;
		for(Articolo b :a) {
			if(AddArticolo(b))flag=false;
		}
		if(flag)throw new Exception();
		this.t = Stato.NON_PAGATO;
	}
	
	public void Paga() {
		int conto=this.a.stream().mapToInt(f->((Articolo) f).getCosto()).sum();
		System.out.println("Prezzo da Pagare: "+conto+" Vuoi procedere con il pagamento? S/N");
		try {
			if(st.nextToken()==StreamTokenizer.TT_WORD && st.sval.equals("S"))setT(Stato.PAGATO);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	public boolean AddArticolo(Articolo b) {
		if(b.getQuantita()==0)return false;
		else {
			boolean f=this.a.add(b);
			if(f) {
				b.setQuantita((b.getQuantita())-1);
				return f;
			}
			return false;
			
		}
		
	}

	public Stato getT() {
		return t;
	}

	public void setT(Stato t) {
		this.t = t;
	}
	
}
