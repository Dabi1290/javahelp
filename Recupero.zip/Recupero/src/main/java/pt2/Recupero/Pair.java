package pt2.Recupero;

public class Pair <T>{
	private T x,y;
	public T getX() {
		return x;
	}
	public void setX(T x) {
		this.x = x;
	}
	public T getY() {
		return y;
	}
	public void setY(T y) {
		this.y = y;
	}
	public Pair(T x, T y) {
		super();
		this.x = x;
		this.y = y;
	}
	public static <T extends Comparable<? super T>> T min(Pair <T> p){
			if(p.getX().compareTo(p.getY())>0)return p.getY();
			else return p.getX();
	}
	

}
