package pt2.Recupero;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pair p= new Pair(7,2);
		
		System.out.println(Pair.min(p));

	}

}
