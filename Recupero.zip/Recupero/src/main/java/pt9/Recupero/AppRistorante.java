package pt9.Recupero;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

public class AppRistorante {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		Scanner sc= new Scanner(System.in);
		DateFormat df;
		Date date;
		df= new SimpleDateFormat("dd/MM/yyyy");
		date= df.parse(sc.next());
		System.out.println(df.format(new Date()));
		System.out.println(df.format(date));
	}

}
