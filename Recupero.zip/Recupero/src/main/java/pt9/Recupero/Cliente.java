package pt9.Recupero;

public class Cliente {
private String nome;
private String cognome;
private String Indirizzo;
private String numeroTel;
public String getNome() {
	return nome;
}
public void setNome(String nome) {
	this.nome = nome;
}
public String getCognome() {
	return cognome;
}
public void setCognome(String cognome) {
	this.cognome = cognome;
}
public String getIndirizzo() {
	return Indirizzo;
}
public void setIndirizzo(String indirizzo) {
	Indirizzo = indirizzo;
}
public String getNumeroTel() {
	return numeroTel;
}
public void setNumeroTel(String numeroTel) {
	this.numeroTel = numeroTel;
}
public Cliente(String nome, String cognome, String indirizzo, String numeroTel) {
	super();
	this.nome = nome;
	this.cognome = cognome;
	Indirizzo = indirizzo;
	this.numeroTel = numeroTel;
}

}
