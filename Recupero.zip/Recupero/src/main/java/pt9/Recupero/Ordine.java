package pt9.Recupero;

import java.util.Date;
import java.util.List;

public class Ordine {
 private  Date data;
 private Integer quantita;
 private String descrizione;
 
 enum Tipo{
	 Primo(5),
	 Secondo(10),
	 Antipasto(13);
	 private int prezzo;
	 Tipo(int i) {
		 this.prezzo=i;
	}
	public int getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(int prezzo) {
		this.prezzo = prezzo;
	}
 }
 private List <Tipo> a;
public Ordine(Date data, Integer quantita, String descrizione, Tipo ...t ) {
	super();
	this.data = data;
	this.quantita = quantita;
	this.descrizione = descrizione;
	for(Tipo l:t) {
		this.a.add(l);
	}
}

public Integer Totale() {
	return a.stream().mapToInt(f->f.getPrezzo()).sum();
}

}
