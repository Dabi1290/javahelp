package FirstBecomeLastChar.Fblc;
import java.util.*;  
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 System.out.println( "Inserisci una parola di almeno due caratteri" );
         Scanner sc= new Scanner(System.in);
         String sos=sc.nextLine();
         while(sos.length()<2) {
        	 System.out.println( "ALMENO DUE CARATTERI!!!\nInserisci una parola di almeno due caratteri" );
        	 sos=sc.nextLine();
         }
         String ciao=sos.charAt(sos.length()-1)+sos.substring(1, sos.length()-1)+sos.charAt(0);
         
         
         System.out.println(ciao);
        
         
    }
}
