package Geometria.Rettangolo;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws Exception
    {
    	
    	
    	//ESERCIZIO 1
    	 Rettangolo r=new Rettangolo(2.3,4.5);
    	 Rettangolo r1=new Rettangolo(4.5,2.3);
    	 System.out.println("Perimetro r: "+r.perimetro()+"\nArea r: "+r.area());
    	// ESERCIZIO 2
    	 r.toString();
    	 if(r.equals(r1))System.out.println(r.toString()+"\nTRUE");
    	 else System.out.println(r.toString()+"\nFALSE");
    	// ESERCIZIO 3
    	 if(r.compareTo(r1)==0)System.out.println("Siamo UGUALI");
    	 else if(r.compareTo(r1)>0)System.out.println("Sono GRANDE");
    	 else System.out.println("Sono PICCOLO");
    	// ESERCIZIO 4
    	 Quadrato q=new Quadrato(2.3,2.3);
         System.out.println(q.toString());
        // ESERCIZIO 5
         Quadrato q1=new Quadrato(2.3,2.3);
         	// COMPARE TO() TRA QUADRATI
         if(q.compareTo(q1)==0)System.out.println("Siamo UGUALI");
    	 else if(q.compareTo(q1)>0)System.out.println("Sono GRANDE");
    	 else System.out.println("Sono PICCOLO");
         	// COMPARE TO() TRA QUADRATO RETTANGOLO
         if(q.compareTo(r1)==0)System.out.println("Siamo UGUALI");
    	 else if(q.compareTo(r1)>0)System.out.println("Sono GRANDE");
    	 else System.out.println("Sono PICCOLO");
        // ESERCIZIO 6
         System.out.println("HASH:\nRettangolo: "+r.hashClass()+"\nQuadrato: "+q.hashClass());
        // ESERCIZIO 7
         System.out.println("Base64:  "+r.serializza());
    	 
    	
    }
}
