package Geometria.Rettangolo;

import java.util.Objects;
import org.apache.commons.codec.*;
import org.apache.commons.codec.*;
import org.apache.commons.codec.StringEncoder;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;

public class Rettangolo implements Comparable<Rettangolo>{
	private double base;
	private double altezza;
	public double area(){
		return (this.base*this.altezza)/2;
	}
	public double perimetro() {
		return (this.base+this.altezza)*2;
	}
	public Rettangolo(double base, double altezza) {
		super();
		this.base = base;
		this.altezza = altezza;
	}
	public double getBase() {
		return base;
	}
	public void setBase(double base) {
		this.base = base;
	}
	@Override
	public String toString() {
		return "Sono un rettangolo che copre un area di "+ this.area();
	}
	public double getAltezza() {
		return altezza;
	}
	public void setAltezza(double altezza) {
		this.altezza = altezza;
	}
	@Override
	public int hashCode() {
		return Objects.hash(altezza, base);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		if(!(obj instanceof Rettangolo)) return false;
		if(this.area()==((Rettangolo) obj).area())return true;
		else return false;
	}
	@Override
	public int compareTo(Rettangolo o) {
		if(this.area()==o.area())return 0;
		else if(this.area()>o.area()) return 1;
		else return -1;
		
	}
	public String hashClass() {
		return DigestUtils.sha3_512Hex(this.toString());
		
	}
	public String serializza() {
		return Base64.encodeBase64String(this.toString().getBytes());
				
	}
	
}



