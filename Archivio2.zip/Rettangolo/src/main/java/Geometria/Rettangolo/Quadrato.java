package Geometria.Rettangolo;

public class Quadrato extends Rettangolo {

	public Quadrato(double base, double altezza) throws Exception {
		super(base, altezza);
		if(altezza!=base)
			throw new Exception("Impossibile avere quadrato con base e altezza diversi");
		// TODO Auto-generated constructor stub
	}

	private Quadrato(double base) {
		super(base, base);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Sono un quadrato che copre un area di " + area();
	}

	@Override
	public void setBase(double base) {
		// TODO Auto-generated method stub
		super.setBase(base);
		super.setAltezza(base);
	}

	@Override
	public void setAltezza(double altezza) {
		// TODO Auto-generated method stub
		super.setAltezza(altezza);
		super.setBase(altezza);
	}
	
	
	
	
}
