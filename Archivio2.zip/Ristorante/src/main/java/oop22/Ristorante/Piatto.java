package oop22.Ristorante;

public class Piatto extends Consumed{
	
	



	public Piatto(String nome, Double prezzo) {
		super(nome, prezzo);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return getNome() + getPrezzo();
	}
	
}
