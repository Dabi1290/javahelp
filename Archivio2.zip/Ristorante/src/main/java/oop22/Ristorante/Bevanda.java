package oop22.Ristorante;

public class Bevanda extends Consumed{
	
	public Bevanda(String nome, Double prezzo) {
		super(nome, prezzo);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return getNome() + getPrezzo();
	}
	
	
}
