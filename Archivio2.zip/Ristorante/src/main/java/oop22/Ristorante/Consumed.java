package oop22.Ristorante;

public class Consumed {
	public Consumed(String nome, Double prezzo) {
		super();
		Nome = nome;
		Prezzo = prezzo;
	}
	private String Nome;
	private Double Prezzo;
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public Double getPrezzo() {
		return Prezzo;
	}
	public void setPrezzo(Double prezzo) {
		Prezzo = prezzo;
	}
}
