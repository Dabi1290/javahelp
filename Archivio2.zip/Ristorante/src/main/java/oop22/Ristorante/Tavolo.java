package oop22.Ristorante;

import java.util.ArrayList;
import java.util.List;

public class Tavolo {
	private Integer id;
	private Boolean libero;
	private Integer coperti;
	List <Consumed> consumed;
	private Tavolo(Integer id, Boolean libero, Integer coperti) {
		super();
		this.id = id;
		this.libero = libero;
		this.coperti = coperti;
		consumed =new ArrayList<Consumed>();
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Boolean getLibero() {
		return libero;
	}
	public void setLibero(Boolean libero) {
		this.libero = libero;
	}
	public Integer getCoperti() {
		return coperti;
	}
	public void setCoperti(Integer coperti) {
		this.coperti = coperti;
	}
	public boolean AddBevanda(Bevanda b) {
		return consumed.add(b);
	}
	public boolean AddPiatto(Piatto b) {
		return consumed.add(b);
	}
	public boolean RemoveBevanda(Bevanda b) {
		return consumed.remove(b);
	}public boolean RemovePiatto(Piatto b) {
		return consumed.remove(b);
	}
	public Double Conto() {
		Double a=0.0;
		for(Consumed g:this.consumed)a+=g.getPrezzo();
		return a;
	}
	
	
	
	
}
