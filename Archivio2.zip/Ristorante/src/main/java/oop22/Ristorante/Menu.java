package oop22.Ristorante;

import java.util.ArrayList;
import java.util.List;

public class Menu{
	private List <Bevanda> b;
	private List <Piatto> p;
	private Menu() {
		this.b= new ArrayList<Bevanda>();
		this.p= new ArrayList<Piatto>();
	}
	boolean AggiungiBevanda(Bevanda c){
		return b.add(c);
		
	}
	boolean AggiungiPiatto(Piatto c){
		return p.add(c);
		
	}
	boolean RimuoviBevanda(Bevanda c){
		return b.remove(c);
		
	}
	boolean RimuoviPiatto(Piatto c){
		return p.remove(c);
		
	}
	
	
}
