package Magazzino.Alimenti;

public class Frutta extends Product {

	private String ldp;

	public Frutta(String nome, String produttore, Double cpc, String distributore, String ldp) {
		super(nome, produttore, cpc, distributore);
		this.ldp = ldp;
		
		
	}
	@Override
	public String toString() {
		return getNome() + "\t" +getProduttore() +"\t\t" + getCpc()+"\t" +getDistributore() + "\t\t" +this.ldp;
	}
	

}
