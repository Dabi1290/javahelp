package Magazzino.Alimenti;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StreamTokenizer;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws NumberFormatException, IOException
    {
    	
    	BufferedReader l= new BufferedReader(new InputStreamReader(System.in));
    	StreamTokenizer st = new StreamTokenizer(l);
        Magazzino m=new Magazzino();
 m.Menu();
        
        Integer b=Integer.parseInt(l.readLine());
		String nome,produttore,distributore,ldp;
		double costo;
        while(b!=6){
        switch(b) {
        
        case 1:
        	System.out.println("Inserisci Nome");
        	nome=l.readLine();
        	System.out.println("Inserisci Produttore");
        	produttore=l.readLine();
        	System.out.println("Inserisci Costo");
        	costo= Double.parseDouble(l.readLine());
        	System.out.println("Inserisci Distributore");
        	distributore=l.readLine();
        	Detersivo d=new Detersivo(nome,produttore,costo,distributore);
        	m.Add(d);
        	break;
        case 2:
        	System.out.println("Inserisci Nome");
        	nome=l.readLine();
        	System.out.println("Inserisci Produttore");
        	produttore=l.readLine();
        	System.out.println("Inserisci Costo");
        	costo= Double.parseDouble(l.readLine());
        	System.out.println("Inserisci Distributore");
        	distributore=l.readLine();
        	System.out.println("Inserisci Luogo produzione");
        	ldp=l.readLine();
        	Frutta f=new Frutta(nome,produttore,costo,distributore,ldp);
        	m.Add(f);
        	break;
        case 3:
        	System.out.println("Inserisci Nome");
        	nome=l.readLine();
        	System.out.println("Inserisci Produttore");
        	produttore=l.readLine();
        	System.out.println("Inserisci Costo");
        	costo= Double.parseDouble(l.readLine());
        	System.out.println("Inserisci Distributore");
        	distributore=l.readLine();
        	System.out.println("Inserisci Luogo produzione");
        	ldp=l.readLine();
        	Carne k=new Carne(nome,produttore,costo,distributore,ldp);
        	m.Add(k);
        	break;
        case 4:
        	System.out.println("Inserisci Nome");
        	nome=l.readLine();
        	System.out.println("Inserisci Produttore");
        	produttore=l.readLine();
        	System.out.println("Inserisci Costo");
        	costo= Double.parseDouble(l.readLine());
        	System.out.println("Inserisci Distributore");
        	distributore=l.readLine();
        	System.out.println("Inserisci Luogo produzione");
        	ldp=l.readLine();
        	Bevanda n=new Bevanda(nome,produttore,costo,distributore);
        	m.Add(n);
        	break;
        case 5:
        	System.out.println("Inserisci elemento da rimuovere ");
        	nome=l.readLine();
        	if(m.Remove(nome))System.out.println("Elemento rimosso con successo!");
        	else System.out.println("Elemento non presente");
        	
        	
        case 6: break;
        case 7: m.MagShow();
        }
        m.Menu();
       b=Integer.parseInt(l.readLine());
        }
        l.close();
    }
    
}
