package Magazzino.Alimenti;

public class Product implements Comparable<Product>{
	
	private String nome;
	private String produttore;
	private Double cpc;
	private String distributore;
	
	public Product(String nome, String produttore, Double cpc, String distributore) {
		super();
		this.nome = nome;
		this.produttore = produttore;
		this.cpc = cpc;
		this.distributore = distributore;
		
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getProduttore() {
		return produttore;
	}
	public void setProduttore(String produttore) {
		this.produttore = produttore;
	}
	public Double getCpc() {
		return cpc;
	}
	public void setCpc(Double cpc) {
		this.cpc = cpc;
	}
	public String getDistributore() {
		return distributore;
	}
	public void setDistributore(String distributore) {
		this.distributore = distributore;
	}

	@Override
	public int compareTo(Product o) {
		if(o.nome.compareTo(this.getNome())==0) return 0;
		else return 1;
		
	}
	
	
}
