package Magazzino.Alimenti;

import java.util.ArrayList;
import java.util.List;

public class Magazzino {
	
	List<Product> magazz;
	public Magazzino() {
		magazz=new ArrayList<Product>();
	}
	
	public boolean Add(Product a) {
		return this.magazz.add(a);
	}
	public boolean Remove(String a) {
		Product t=this.Find(a);
		if(t!=null)
			return this.magazz.remove(t);
		else return false;
	}
	public Product Find(String nome) {
		Product p= new Product(nome,null,null,null);
		for (Product var : this.magazz) 
		{ 
		    if(var.compareTo(p)==0)return var;
		}
		return null;
	}
	public void MagShow() {
		System.out.format("NOME\tPRODUTTORE\tCOSTO\tDISTRIBUTORE\tLUOGO DI PROVENIENZA\t\n");
		for(Product a: this.magazz) 
			System.out.println(a.toString()+"\n");
		
		
	}
	public void Menu() {
		System.out.println("1) Aggiungi Detersivo ");
		System.out.println("2) Aggiungi Frutta");
		System.out.println("3) Aggiungi Carne");
		System.out.println("4) Aggiungi Bevanda");
		System.out.println("5) Rimuovi prodotto");
		System.out.println("7) Stampa");
		System.out.println("6) Esci ");
		
	}

	
}
