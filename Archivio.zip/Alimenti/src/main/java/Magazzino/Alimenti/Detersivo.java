package Magazzino.Alimenti;

public class Detersivo extends Product {

	public Detersivo(String nome, String produttore, Double cpc, String distributore) {
		super(nome, produttore, cpc, distributore);
		// TODO Auto-generated constructor stub
		
	}

	@Override
	public String toString() {
		return getNome() + "\t" +getProduttore() +"\t\t" + getCpc()+"\t" +getDistributore() ;
	}
}
