package MidChar.App;
import java.util.*;  
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( args[0].charAt(args[0].length()/2));
        
        System.out.println( args[0].charAt(0) +""+ args[1].charAt(0) +""+ args[2].charAt(0));
        
        System.out.println( args[0].indexOf("f"));
    }
}
