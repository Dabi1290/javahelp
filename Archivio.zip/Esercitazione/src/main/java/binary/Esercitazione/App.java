package binary.Esercitazione;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws NumberFormatException, IOException
    {
        BufferedReader b= new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserisci numero");
        
        Integer a= Integer.parseInt(b.readLine());
        String s=Integer.toBinaryString(a);
        List<String> l=new ArrayList();
        List<String> l1=new ArrayList();
        System.out.println(s);
        System.out.print("Complemento a uno: ");
        for(int i=0;i<s.length();i++){
        	if(s.charAt(i)=='1')l.add("0");
        	else l.add("1");
        }
        System.out.print(l);
        System.out.print("\nComplemento a due: ");
        boolean flag=false;
        for(int i=s.length()-1;i>0;i--){
        	if(l.get(i)=="1")l.set(i, "0");
        	else {l.set(i, "1");flag=true;break;}
        }
        if(!flag)l.add(0, "1");
        System.out.print(l);
        
    }
}
